# MyNews

Introduction

Vous avez codé toute la journée, la fatigue vous gagne. Vous commencez à loucher et à bailler à vous décrocher la mâchoire. Il vous faut votre dose de café pour tenir. En sortant de chez vous pour vous rendre au Starbucks du coin, vous vous surprenez à lire un grand titre sur une façade de kiosque : “Donald Trump félicite Emmanuel Macron pour sa victoire”. Tiens donc, quelle victoire ? D’ailleurs c’est qui Macron ? Et Trump ?

De retour chez vous, votre Latte Glacé à la main devant Wikipedia, vous découvrez avec stupeur que vous avez deux wagons de retard. Obama n’est plus le Président américain ? Sarkozy n’est plus le Président français depuis autant d'années ?

Cela ne peut plus durer, il est grand temps d’être à la page. Vous pourriez télécharger une application de news toute faite, mais vous préférez la développer vous-même : vous pourrez ainsi déterminer les sujets qui vous intéressent et créer une application qui vous ressemble. Vous décidez de la baptiser MyNews.
