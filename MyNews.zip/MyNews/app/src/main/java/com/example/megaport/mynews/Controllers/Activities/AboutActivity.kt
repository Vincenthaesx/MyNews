package com.example.megaport.mynews.Controllers.Activities

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.ImageButton
import android.widget.Toolbar

import com.example.megaport.mynews.R

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.about_activity)

        val imageButton = findViewById<ImageButton>(R.id.image_button_about)

        imageButton.setOnClickListener { view -> startActivity() }

    }

    private fun startActivity() {
        Intent (this, MainActivity::class.java)
        startActivity((intent))
    }
}
