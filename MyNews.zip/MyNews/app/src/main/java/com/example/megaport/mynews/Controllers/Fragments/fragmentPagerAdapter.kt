package com.example.megaport.mynews.Controllers.Fragments

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter

// Class used to create the different tabs displayed on the action bar

class fragmentPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {
    private val tabTitles = arrayOf("TOP STORIES", "MOST POPULAR", "POLITICS")
    private val listFragment = listOf(MainFragment.newInstance(0),
            MainFragment.newInstance(1),
            MainFragment.newInstance(2))

    override fun getCount(): Int {
        return listFragment.size
    }

    override fun getItem(position: Int): Fragment {
        listFragment[position]
    }

    // Generate title based on item position
    override fun getPageTitle(position: Int): CharSequence? {
        return tabTitles[position]
    }
}