package com.example.megaport.mynews.Controllers.Activities

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.design.widget.TabLayout
import android.support.v4.view.GravityCompat
import android.support.v4.view.ViewPager
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.ActionBarDrawerToggle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.Menu
import android.view.MenuItem
import com.example.megaport.mynews.Controllers.Fragments.MainFragment
import com.example.megaport.mynews.Controllers.Fragments.fragmentPagerAdapter
import com.example.megaport.mynews.R

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    //FOR DESIGN
    private var toolbar: Toolbar? = null
    private var drawerLayout: DrawerLayout? = null

    // FOR RECYCLERVIEW
    private var mainFragment = supportFragmentManager.findFragmentById(R.id.activity_main_frame_layout) as MainFragment?
    private var mViewPager: ViewPager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        this.configureToolBar()

        this.configureDrawerLayout()

        this.configureNavigationView()


        if (savedInstanceState == null) {
            this.configureAndShowMainFragment()
        } else {
            mainFragment = supportFragmentManager.findFragmentById(R.id.activity_main_frame_layout) as MainFragment?
        }

        // Get the ViewPager and set it's PagerAdapter so that it can display items
        mViewPager = findViewById(R.id.viewpager)
        mViewPager!!.adapter = fragmentPagerAdapter(supportFragmentManager
        )

        // Give the TabLayout the ViewPager
        val tabLayout = findViewById<TabLayout>(R.id.sliding_tabs)
        tabLayout.setupWithViewPager(mViewPager)
        tabLayout.addOnTabSelectedListener(object : TabLayout.ViewPagerOnTabSelectedListener(mViewPager) {
            override fun onTabSelected(tab: TabLayout.Tab) {
                super.onTabSelected(tab)
                mViewPager!!.currentItem = tab.position
                tabPos = tab.position
                mainFragment!!.executeHttpRequestWithRetrofit()
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
                mainFragment!!.executeHttpRequestWithRetrofit()
            }
        })
    }

    // --------
    // TOOLBAR
    // --------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.activity_main_menu_toolbar, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.activity_main_toolbar_search -> {
                val intentSearch = Intent(this, SearchActivity::class.java)
                startActivity(intentSearch)
            }
            R.id.activity_main_toolbar_help -> {
                val intentHelp = Intent(this, HelpActivity::class.java)
                startActivity(intentHelp)
            }
            R.id.activity_main_toolbar_about -> {
                val intentAbout = Intent(this, AboutActivity::class.java)
                startActivity(intentAbout)
            }
            else -> {
            }
        }

        return true
    }

    // -------------

    override fun onBackPressed() {
        // 5 - Handle back click to close menu
        if (this.drawerLayout!!.isDrawerOpen(GravityCompat.START)) {
            this.drawerLayout!!.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    // -------------------
    // NAVIGATION DRAWER
    // -------------------

    override fun onNavigationItemSelected(item: MenuItem): Boolean {

        // 4 - Handle Navigation Item Click
        val id = item.itemId

        when (id) {
            R.id.activity_main_drawer_top_stories -> mViewPager!!.currentItem = 0
            R.id.activity_main_drawer_most_popular -> mViewPager!!.currentItem = 1
            R.id.activity_main_drawer_notification -> {
                val intentNotification = Intent(this, NotificationsActivity::class.java)
                startActivity(intentNotification)
            }
            R.id.activity_main_drawer_help -> {
                val intentHelp = Intent(this, HelpActivity::class.java)
                startActivity(intentHelp)
            }
            R.id.activity_main_drawer_about -> {
                val intentAbout = Intent(this, AboutActivity::class.java)
                startActivity(intentAbout)
            }
            else -> {
            }
        }

        this.drawerLayout!!.closeDrawer(GravityCompat.START)

        return true
    }

    // ---------------------
    // CONFIGURATION
    // ---------------------

    // 1 - Configure Toolbar
    private fun configureToolBar() {
        this.toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
    }

    // 2 - Configure Drawer Layout
    private fun configureDrawerLayout() {
        this.drawerLayout = findViewById(R.id.activity_main_drawer_layout)
        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close)
        drawerLayout!!.addDrawerListener(toggle)
        toggle.syncState()
    }

    // 3 - Configure NavigationView
    private fun configureNavigationView() {
        val navigationView = findViewById<NavigationView>(R.id.activity_main_nav_view)
        navigationView.setNavigationItemSelectedListener(this)
    }

    private fun configureAndShowMainFragment() {
        if (mainFragment == null) {
            mainFragment = MainFragment()
            supportFragmentManager.beginTransaction()
                    .add(R.id.activity_main_frame_layout, mainFragment!!)
                    .commit()
        }
    }

    companion object {
        var tabPos = 0
    }

}