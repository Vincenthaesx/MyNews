package com.example.megaport.mynews.Controllers.Utils

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context

class MyApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        MyApplication.appContext = applicationContext
    }

    companion object {

        @SuppressLint("StaticFieldLeak")
        var appContext: Context? = null
            private set
    }
}
