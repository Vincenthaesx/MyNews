package com.example.megaport.mynews.Controllers.Activities

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.example.megaport.mynews.Controllers.Fragments.search_fragment
import com.example.megaport.mynews.R

class SearchResultActivity : AppCompatActivity() {

    private var searchFragment = supportFragmentManager.findFragmentById(R.id.activity_search_frame_layout) as search_fragment<Any?>?

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_result)

        // Retrieving extras from the intent
        val intent = intent
        val sDate = intent.getStringExtra("start_date")
        val eDate = intent.getStringExtra("end_date")
        val query = intent.getStringExtra("SearchQuery")
        val section = intent.getStringExtra("section")


        if (savedInstanceState == null) {
            this.configureAndShowSearchFragment(query, sDate, eDate, section)
        } else {
            searchFragment = supportFragmentManager.findFragmentById(R.id.activity_search_frame_layout) as search_fragment<Any?>?
        }

    }

    private fun configureAndShowSearchFragment(query: String, sDate: String, eDate: String, section: String) {
        if (searchFragment == null) {
            searchFragment = search_fragment()
            val bundle = Bundle()
            bundle.putString("query", query)
            bundle.putString("sDate", sDate)
            bundle.putString("eDate", eDate)
            bundle.putString("section", section)
            searchFragment!!.arguments = bundle
            supportFragmentManager.beginTransaction()
                    .add(R.id.activity_search_frame_layout, searchFragment!!)
                    .commit()
        }
    }
}
