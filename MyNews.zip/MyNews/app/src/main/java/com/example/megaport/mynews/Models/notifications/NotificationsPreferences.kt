package com.example.megaport.mynews.Models.notifications

// Model for notifications

class NotificationsPreferences(var queryTerm: String?, var categoryList: List<String>?, var isEnabled: Boolean) {
    companion object {
        val DEFAULT_QUERY_TERM = ""
        val DEFAULT_CATEGORY_LIST = ""
    }
}