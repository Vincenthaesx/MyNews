package com.example.megaport.mynews.Models.notifications

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

internal class ResponseMultimedia(@field:SerializedName("url")
                                  @field:Expose
                                  val url: String)