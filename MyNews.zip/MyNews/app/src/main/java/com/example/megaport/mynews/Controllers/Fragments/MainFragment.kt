package com.example.megaport.mynews.Controllers.Fragments

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.example.megaport.mynews.Controllers.Activities.MainActivity
import com.example.megaport.mynews.Controllers.Activities.WebViewActivity
import com.example.megaport.mynews.Controllers.Utils.ItemClickSupport
import com.example.megaport.mynews.Controllers.Utils.MyNewsStreams
import com.example.megaport.mynews.Models.Article
import com.example.megaport.mynews.Models.Articles
import com.example.megaport.mynews.R
import com.example.megaport.mynews.Views.FragmentAdapter
import java.util.ArrayList
import io.reactivex.disposables.Disposable
import io.reactivex.observers.DisposableObserver
import kotlinx.android.synthetic.main.fragment_main.*

// Class used for all fragment

class MainFragment : Fragment(), FragmentAdapter.Listener {

    //FOR DATA
    private var disposable: Disposable? = null
    private var articleList: MutableList<Article>? = null
    private var adapter: FragmentAdapter? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_main, container, false)
        this.configureRecyclerView()
        this.configureSwipeRefreshLayout()
        this.configureOnClickRecyclerView()
        this.executeHttpRequestWithRetrofit()
        fragment_main_swipe_container.isRefreshing = false
        return view
    }

    override fun onDestroy() {
        super.onDestroy()
        this.disposeWhenDestroy()
    }

    // -----------------
    // ACTION
    // -----------------


    // Load the URL of an article in the WebView activity

    private fun configureOnClickRecyclerView() {
//        ItemClickSupport.addTo(fragment_main_recycler_view, R.layout.fragment_main_item)
//                .setOnItemClickListener { fragment_main_recycler_view, position, v ->
//                    val article = adapter!!.getArticle(position)
//                    val intent = Intent(context, WebViewActivity::class.java)
//                    intent.putExtra("Url", article.url)
//                    startActivity(intent)
//                }
        ItemClickSupport.addTo(fragment_main_recycler_view, R.layout.fragment_main_item).setOnItemClickListener { _, position, _ ->
            fragment_main_recycler_view.adapter?.safeCast<FragmentAdapter> {
                val applications = it.getApplications(position)
                val intent = Intent(context, BranchActivity::class.java)
                intent.putExtra("id", applications.id)
                startActivity(intent)
            }
        }
    }

    // -----------------
    // CONFIGURATION
    // -----------------

    // Configure the RecyclerView by creating a new adapter object and attaching it to the RecyclerView

    private fun configureRecyclerView() {
        this.articleList = ArrayList()
        val articles = Articles()
        articles.articles = articleList
        // Create adapter passing in the sample result data
        this.adapter = FragmentAdapter(articles, Glide.with(this), this)
        // Attach the adapter to the recyclerview to populate items
        fragment_main_recycler_view.adapter = this.adapter
        // Set layout manager to position the items
        fragment_main_recycler_view.layoutManager = LinearLayoutManager(activity)
    }

    // Will trigger a new Http request to the API when the user swipe from the top to the bottom

    private fun configureSwipeRefreshLayout() {
        fragment_main_swipe_container.setOnRefreshListener{ this.executeHttpRequestWithRetrofit() }
    }

    // -------------------
    // HTTP (RxJAVA)
    // -------------------

    // Will execute a Http request with retrofit

    fun executeHttpRequestWithRetrofit() {
        val mProgressDialog = ProgressDialog(activity)
        mProgressDialog.isIndeterminate = true
        mProgressDialog.setMessage("Loading...")
        mProgressDialog.show()
        when (MainActivity.tabPos) {
            0 -> this.disposable = MyNewsStreams.streamFetchTopStories("home").subscribeWith(object : DisposableObserver<Articles>() {
                override fun onNext(stories: Articles) {
                    updateUI(stories.articles)
                }

                override fun onError(e: Throwable) {
                    Log.e("TAG", "error request")
                }

                override fun onComplete() {
                    mProgressDialog.dismiss()
                }
            })
            1 -> this.disposable = MyNewsStreams.streamFetchMostPopular().subscribeWith(object : DisposableObserver<Articles>() {
                override fun onNext(stories: Articles) {
                    updateUI(stories.articles)
                }

                override fun onError(e: Throwable) {
                    Log.e("TAG", "error request")
                }

                override fun onComplete() {
                    mProgressDialog.dismiss()
                }
            })
            2 -> this.disposable = MyNewsStreams.streamFetchTopStories("politics").subscribeWith(object : DisposableObserver<Articles>() {
                override fun onNext(stories: Articles) {
                    updateUI(stories.articles)
                }

                override fun onError(e: Throwable) {
                    Log.e("TAG", "error request")
                }

                override fun onComplete() {
                    mProgressDialog.dismiss()
                }
            })
        }

    }

    // Perform any final cleanup before an activity is destroyed.

    private fun disposeWhenDestroy() {
        if (this.disposable != null && !this.disposable!!.isDisposed) this.disposable!!.dispose()
    }

    // -------------------
    // UPDATE UI
    // -------------------

    // Update the UI with the new values retrieved by the HTTP request

    private fun updateUI(res: List<Article>?) {
        articleList!!.clear()
        articleList!!.addAll(res!!)
        adapter!!.notifyDataSetChanged()
        fragment_main_swipe_container.isRefreshing = false
    }

    companion object {

        private const val POSITION = "position"

        fun newInstance(position : Int) : MainFragment {
            val fragment =  MainFragment()
            val bundle = Bundle().apply {
                putInt(POSITION, position)
            }
            fragment.arguments = bundle
            return fragment

        }
    }
}