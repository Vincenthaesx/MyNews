package com.example.megaport.mynews.Controllers.Fragments

import android.app.ProgressDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.megaport.mynews.Controllers.Activities.WebViewActivity
import com.example.megaport.mynews.Controllers.Utils.ItemClickSupport
import com.example.megaport.mynews.Controllers.Utils.MyApplication
import com.example.megaport.mynews.Controllers.Utils.MyNewsStreams
import com.example.megaport.mynews.Models.Article
import com.example.megaport.mynews.Models.Articles
import com.example.megaport.mynews.Models.Result
import com.example.megaport.mynews.R
import com.example.megaport.mynews.Views.searchAdapter
import java.util.ArrayList
import java.util.Objects
import butterknife.BindView
import butterknife.ButterKnife
import io.reactivex.disposables.Disposable
import io.reactivex.observers.DisposableObserver

class search_fragment<FragmentActivity> : Fragment(), searchAdapter.Listener {

    // FOR DESIGN
    @BindView(R.id.fragment_search_recycler_view)
    internal var recyclerViewSearch: RecyclerView? = null
    @BindView(R.id.fragment_search_swipe_container)
    internal var swipeRefreshLayoutSearch: SwipeRefreshLayout? = null

    //FOR DATA
    private var disposableSearch: Disposable? = null
    private var articleList2: MutableList<Article>? = null
    private var adapterSearch: searchAdapter? = null
    private var query = ""
    private var start_date = ""
    private var end_date = ""
    private var section = ""

    @RequiresApi(api = Build.VERSION_CODES.M)
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_search_fragment, container, false)
        ButterKnife.bind(this, view)
        val bundle = this.arguments
        if (bundle != null) {
            query = bundle.getString("query", null)
            start_date = bundle.getString("sDate", null)
            end_date = bundle.getString("eDate", null)
            section = bundle.getString("section", "type_of_material:News")
        }
        this.configureRecyclerView()
        this.configureSwipeRefreshLayout()
        this.configureOnClickRecyclerView()
        this.executeHttpRequestWithRetrofit()
        swipeRefreshLayoutSearch!!.isRefreshing = false
        return view
    }

    override fun onDestroy() {
        super.onDestroy()
        this.disposeWhenDestroy()
    }

    // -----------------
    // ACTION
    // -----------------

    // Load the URL of an article in the WebView activity

    @RequiresApi(api = Build.VERSION_CODES.M)
    private fun configureOnClickRecyclerView() {
        ItemClickSupport.addTo(recyclerViewSearch!!, R.layout.fragment_search_item)
                .setOnItemClickListener { recyclerView, position, v ->
                    val article = adapterSearch!!.getArticle(position)
                    val intent = Intent(context, WebViewActivity::class.java)
                    intent.putExtra("Url", article.webUrl)
                    startActivity(intent)
                }
    }

    // -----------------
    // CONFIGURATION
    // -----------------

    // Configure the RecyclerView by creating a new adapter object and attaching it to the RecyclerView

    private fun configureRecyclerView() {
        this.articleList2 = ArrayList()
        val articles2 = Articles()
        articles2.articles = articleList2
        // Create adapter passing in the sample result data
        this.adapterSearch = searchAdapter(articles2, Glide.with(this), this)
        // Attach the adapter to the recyclerview to populate items
        this.recyclerViewSearch!!.adapter = this.adapterSearch
        // Set layout manager to position the items
        this.recyclerViewSearch!!.layoutManager = LinearLayoutManager(activity)
    }

    // Will trigger a new Http Request when the user swipe

    private fun configureSwipeRefreshLayout() {
        swipeRefreshLayoutSearch!!.setOnRefreshListener { this.executeHttpRequestWithRetrofit() }
    }

    // -------------------
    // HTTP (RxJAVA)
    // -------------------

    // Will execute a Http request with RxJAVA and Retrofit

    private fun executeHttpRequestWithRetrofit() {
        val mProgressDialog = ProgressDialog(activity)
        mProgressDialog.isIndeterminate = true
        mProgressDialog.setMessage("Loading...")
        mProgressDialog.show()
        this.disposableSearch = MyNewsStreams.streamFetchSearch(query, start_date, end_date, section).subscribeWith(object : DisposableObserver<Result>() {
            override fun onNext(result: Result) {
                updateUISearch(result.articles!!.articles)
            }

            override fun onError(e: Throwable) {}

            override fun onComplete() {
                mProgressDialog.dismiss()
            }
        })
    }

    // Perform any final cleanup before an activity is destroyed.

    private fun disposeWhenDestroy() {
        if (this.disposableSearch != null && !this.disposableSearch!!.isDisposed) this.disposableSearch!!.dispose()
    }

    // -------------------
    // UPDATE UI
    // -------------------

    // Update the UI With the new values retrieved by the HTTP request

    private fun updateUISearch(res: List<Article>?) {
        articleList2!!.clear()
        articleList2!!.addAll(res!!)
        if (articleList2!!.size == 0) {
            Objects.requireNonNull<FragmentActivity>(activity).onBackPressed()
            Toast.makeText(MyApplication.appContext, "No article found with current parameters", Toast.LENGTH_LONG).show()
        }
        adapterSearch!!.notifyDataSetChanged()
        swipeRefreshLayoutSearch!!.isRefreshing = false
    }
}
