package com.example.megaport.mynews.Views

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.RequestManager
import com.example.megaport.mynews.Models.Article
import com.example.megaport.mynews.Models.Articles
import com.example.megaport.mynews.R

class FragmentAdapter// CONSTRUCTOR
(articles: Articles, private val glide: RequestManager, // FOR COMMUNICATION
 private val callback: Listener) : RecyclerView.Adapter<FragmentViewHolder>() {

    private val articleList: List<Article>?

    interface Listener

    init {
        this.articleList = articles.articles
    }

    // Create view holder and inflating its xml layout

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FragmentViewHolder {
        val context = parent.context
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.fragment_top_stories_item, parent, false)

        return FragmentViewHolder(view)
    }

    // Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.

    override fun onBindViewHolder(viewHolder: FragmentViewHolder, position: Int) {
        viewHolder.updateWithResult(this.articleList!![position], this.glide, this.callback)
    }


    // Returns the total count of items in the list

    override fun getItemCount(): Int {
        return this.articleList!!.size
    }


    // Returns a specific result in the results list

    fun getArticle(position: Int): Article {
        return this.articleList!![position]
    }
}
