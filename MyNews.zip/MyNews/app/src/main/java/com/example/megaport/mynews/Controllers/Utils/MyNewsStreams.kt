package com.example.megaport.mynews.Controllers.Utils

import android.text.TextUtils.isEmpty
import com.example.megaport.mynews.Models.Articles
import com.example.megaport.mynews.Models.Result
import com.example.megaport.mynews.Models.notifications.MyNewsResultAPI
import java.util.concurrent.TimeUnit
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.annotations.Nullable
import io.reactivex.schedulers.Schedulers

object MyNewsStreams {

    // TopStories
    fun streamFetchTopStories(key: String): Observable<Articles> {
        val newsService = MyNewsService.retrofit.create<MyNewsService>(MyNewsService::class.java)

        return newsService.getTopStoriesArticles(key)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .timeout(10, TimeUnit.SECONDS)
    }

    // MostPopular
    fun streamFetchMostPopular(): Observable<Articles> {
        val nyTimesService = MyNewsService.retrofit.create<MyNewsService>(MyNewsService::class.java)
        return nyTimesService.mostPopular()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .timeout(10, TimeUnit.SECONDS)
    }

    // Search
    fun streamFetchSearch(query: String?, start_date: String?, end_date: String?, section: String): Observable<Result> {
        var query = query
        var start_date = start_date
        var end_date = end_date
        val nyTimesService = MyNewsService.retrofit.create<MyNewsService>(MyNewsService::class.java)
        if (query!!.isEmpty())
            query = null
        if (start_date!!.isEmpty())
            start_date = null
        if (end_date!!.isEmpty())
            end_date = null
        return nyTimesService.getSearch(query, start_date, end_date, section)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .timeout(10, TimeUnit.SECONDS)
    }

    // Notification
    fun streamFetchNotifications(toSearch: String?, @Nullable filterQuery: List<String>, @Nullable beginDate: String?, @Nullable endDate: String?): Observable<MyNewsResultAPI> {
        val nyTimesService = MyNewsService.retrofit.create<MyNewsService>(MyNewsService::class.java)
        return nyTimesService.getResultForNotification(toSearch, filterQuery, beginDate, endDate)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .timeout(10, TimeUnit.SECONDS)
    }
}
