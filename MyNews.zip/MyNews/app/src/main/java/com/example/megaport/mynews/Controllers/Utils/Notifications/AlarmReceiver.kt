package com.example.megaport.mynews.Controllers.Utils.Notifications

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v4.app.NotificationCompat
import android.util.Log

import com.example.megaport.mynews.Controllers.Activities.SearchResultActivity
import com.example.megaport.mynews.Controllers.Utils.MyNewsStreams
import com.example.megaport.mynews.Models.notifications.MyNewsResultAPI
import com.example.megaport.mynews.Models.notifications.NotificationsPreferences
import com.example.megaport.mynews.R
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Calendar
import io.reactivex.disposables.Disposable
import io.reactivex.observers.DisposableObserver
import android.content.Context.MODE_PRIVATE
import com.example.megaport.mynews.Controllers.Activities.NotificationsActivity.Companion.NOTIFICATIONS_STATE
import com.example.megaport.mynews.Controllers.Activities.NotificationsActivity.Companion.PREFS
import com.example.megaport.mynews.Controllers.Activities.NotificationsActivity.NOTIFICATIONS_STATE
import com.example.megaport.mynews.Controllers.Activities.NotificationsActivity.PREFS

class AlarmReceiver : BroadcastReceiver() {

    private var mContext: Context? = null

    override fun onReceive(context: Context, intent: Intent) {
        this.mContext = context
        this.retrieveSharedPreferences()
    }

    private fun retrieveSharedPreferences() {
        val preferences = mContext!!.getSharedPreferences(PREFS, MODE_PRIVATE)
        val gson = Gson()
        val type = object : TypeToken<NotificationsPreferences>() {

        }.type
        val jsonState = preferences.getString(NOTIFICATIONS_STATE, "")
        val notificationsPreferences = gson.fromJson<NotificationsPreferences>(jsonState, type)
        if (notificationsPreferences != null) {
            val queryTerm = notificationsPreferences.queryTerm
            val categoryList = notificationsPreferences.categoryList
            this.executeHttpRequestWithRetrofit(queryTerm, categoryList)
        }
    }

    private fun executeHttpRequestWithRetrofit(queryTerm: String?, categoryList?: List<String>?) {
        val disposable = MyNewsStreams.streamFetchNotifications(queryTerm, categoryList, todayDate(), null).subscribeWith(object : DisposableObserver<MyNewsResultAPI>() {
            override fun onNext(nyTimesResultAPI: MyNewsResultAPI) {
                if (!MyNewsResultAPI.response!!.docs!!.isEmpty()) {
                    sendNotifications(queryTerm, categoryList)
                }
            }

            override fun onError(e: Throwable) {
                Log.e("TAG", "Error request")
            }

            override fun onComplete() {}
        })
    }

    private fun sendNotifications(queryTerm: String?, categoryList: List<String>?) {
        //Intent to invoke app when click on notification.
        val intentToRepeat = Intent(mContext, SearchResultActivity::class.java)
        intentToRepeat.putExtra(QUERY, queryTerm)
        intentToRepeat.putExtra(BEGIN_DATE, todayDate())
        intentToRepeat.putStringArrayListExtra(FILTER_QUERY, categoryList as ArrayList<String>?)
        //set flag to restart/relaunch the app
        intentToRepeat.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP

        //Pending intent to handle launch of Activity in intent above
        val pendingIntent = PendingIntent.getActivity(mContext, NotificationHelper.ALARM_TYPE_RTC, intentToRepeat, PendingIntent.FLAG_UPDATE_CURRENT)

        //Build notification
        val repeatedNotification = buildLocalNotification(mContext, pendingIntent).build()

        //Send local notification
        NotificationHelper.getNotificationManager(mContext!!).notify(NotificationHelper.ALARM_TYPE_RTC, repeatedNotification)
    }

    private fun buildLocalNotification(context: Context?, pendingIntent: PendingIntent): NotificationCompat.Builder {

        return NotificationCompat.Builder(context)
                .setContentIntent(pendingIntent)
                .setSmallIcon(R.drawable.ic_openclassrooms)
                .setContentTitle(NOTIFICATION_TITLE)
                .setContentText(NOTIFICATION_MESSAGE)
                .setAutoCancel(true)
    }

    private fun todayDate(): String {
        @SuppressLint("SimpleDateFormat") val df = SimpleDateFormat("yyyyMMdd")
        return df.format(Calendar.getInstance().time)
    }

    companion object {

        private val NOTIFICATION_TITLE = "MyNews"
        private val NOTIFICATION_MESSAGE = "Articles that may interest you!"

        private val QUERY = "QUERY"
        private val FILTER_QUERY = "FILTER_QUERY"
        private val BEGIN_DATE = "BEGIN_DATE"
    }
}