package com.example.megaport.mynews.Controllers.Activities

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.support.design.widget.TextInputEditText
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import com.example.megaport.mynews.Controllers.Utils.MyApplication
import com.example.megaport.mynews.R
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Calendar
import java.util.Date
import java.util.Objects

class SearchActivity : AppCompatActivity() {

    private var startDate: EditText? = null
    private var endDate: EditText? = null
    private var dateListener: DatePickerDialog.OnDateSetListener? = null
    private var dateListener2: DatePickerDialog.OnDateSetListener? = null
    private var sDate = ""
    private var eDate = ""
    private var date: Date? = null
    private var searchQuery: TextInputEditText? = null
    private var cb_arts: CheckBox? = null
    private var cb_politics: CheckBox? = null
    private var cb_business: CheckBox? = null
    private var cb_sports: CheckBox? = null
    private var cb_entrepreneurs: CheckBox? = null
    private var cb_travel: CheckBox? = null
    private var section = "type_of_material:News"
    private val cb = ArrayList<CheckBox>()

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        // Button return

        val imageButton = findViewById<ImageButton>(R.id.image_button_search_return)

        imageButton.setOnClickListener { view -> startActivity() }

        // Finding the two EditText responsible for managing dates in the search activity
        startDate = findViewById(R.id.search_begin_date)
        endDate = findViewById(R.id.search_end_date)

        // Setting action when the startDate EditText is focused
        startDate!!.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                // Setting up a new Calendar object in order to retrieve the date of the day
                val cal = Calendar.getInstance()
                val year = cal.get(Calendar.YEAR)
                val month = cal.get(Calendar.MONTH)
                val day = cal.get(Calendar.DAY_OF_MONTH)

                // Will create a new DatePickerDialog object with the date of the day
                val dialog = DatePickerDialog(
                        this@SearchActivity,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        dateListener,
                        year,
                        month,
                        day)
                // Set DatePickerDialog background transparent
                Objects.requireNonNull<Window>(dialog.window).setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.show()
            }
        }

        // Same as setOnFocusChangeListener but this time when the EditText has already been modified
        startDate!!.setOnClickListener { v ->
            val cal = Calendar.getInstance()
            val year = cal.get(Calendar.YEAR)
            val month = cal.get(Calendar.MONTH)
            val day = cal.get(Calendar.DAY_OF_MONTH)

            val dialog = DatePickerDialog(
                    this@SearchActivity,
                    android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                    dateListener,
                    year,
                    month,
                    day)
            Objects.requireNonNull<Window>(dialog.window).setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.show()
        }

        endDate!!.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                val cal = Calendar.getInstance()
                val year = cal.get(Calendar.YEAR)
                val month = cal.get(Calendar.MONTH)
                val day = cal.get(Calendar.DAY_OF_MONTH)

                val dialog = DatePickerDialog(
                        this@SearchActivity,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        dateListener2,
                        year,
                        month,
                        day)
                Objects.requireNonNull<Window>(dialog.window).setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.show()
            }
        }

        endDate!!.setOnClickListener { v ->
            val cal = Calendar.getInstance()
            val year = cal.get(Calendar.YEAR)
            val month = cal.get(Calendar.MONTH)
            val day = cal.get(Calendar.DAY_OF_MONTH)

            val dialog = DatePickerDialog(
                    this@SearchActivity,
                    android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                    dateListener2,
                    year,
                    month,
                    day)
            Objects.requireNonNull<Window>(dialog.window).setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.show()
        }

        // Will update the concerned EditText with the date value chosen by the user
        dateListener = { view, year, month, dayOfMonth ->
            var monthS = Integer.toString(month + 1)
            var dayS = Integer.toString(dayOfMonth)
            if (month < 10) {
                monthS = "0$monthS"
            }
            if (dayOfMonth < 10) {
                dayS = "0$dayS"
            }
            startDate!!.setText("$dayS/$monthS/$year")
        }

        dateListener2 = { view, year, month, dayOfMonth ->
            var monthS = Integer.toString(month + 1)
            var dayS = Integer.toString(dayOfMonth)
            if (month < 10) {
                monthS = "0$monthS"
            }
            if (dayOfMonth < 10) {
                dayS = "0$dayS"
            }
            endDate!!.setText("$dayS/$monthS/$year")
        }

        searchQuery = findViewById(R.id.query_include)

        val inputPattern = "dd/MM/yyyy"
        val outputPattern = "yyyyMMdd"
        @SuppressLint("SimpleDateFormat") val inputFormat = SimpleDateFormat(inputPattern)
        @SuppressLint("SimpleDateFormat") val outputFormat = SimpleDateFormat(outputPattern)

        val searchButton = findViewById<Button>(R.id.search_submit_button)
        searchButton.setOnClickListener { view ->
            cb.clear()
            section = "type_of_material:News"
            eDate = ""
            sDate = ""

            cb_arts = findViewById(R.id.search_cb_arts)
            cb_business = findViewById(R.id.search_cb_business)
            cb_politics = findViewById(R.id.search_cb_politics)
            cb_sports = findViewById(R.id.search_cb_sports)
            cb_entrepreneurs = findViewById(R.id.search_cb_entrepreneurs)
            cb_travel = findViewById(R.id.search_cb_travel)

            cb.add(cb_arts)
            cb.add(cb_business)
            cb.add(cb_politics)
            cb.add(cb_sports)
            cb.add(cb_entrepreneurs)
            cb.add(cb_travel)

            var count = 0

            for (i in cb.indices) {
                if (cb[i].isChecked) {
                    if (count == 0) {
                        section = section + " AND news_desk:(" + cb[i].text.toString()
                        count++
                    } else if (count > 0) {
                        section = section + " OR " + cb[i].text.toString()
                        count++
                    }
                }
            }

            if (count > 0)
                section = "$section)"

            if (count == 0) {
                Toast.makeText(MyApplication.appContext, "Please specify at least one category to search", Toast.LENGTH_LONG).show()
            } else if (Objects.requireNonNull<Editable>(searchQuery!!.text).toString().isEmpty() || searchQuery!!.text!!.toString().trim { it <= ' ' }.length == 0) {
                Toast.makeText(MyApplication.appContext, "Please enter at least one term in the search bar", Toast.LENGTH_LONG).show()
            } else {
                try {
                    date = inputFormat.parse(startDate!!.text.toString())
                    sDate = outputFormat.format(date)
                } catch (e: ParseException) {
                    e.printStackTrace()
                }

                try {
                    date = inputFormat.parse(endDate!!.text.toString())
                    eDate = outputFormat.format(date)
                } catch (e: ParseException) {
                    e.printStackTrace()
                }

                val intent = Intent(view.context, SearchResultActivity::class.java)
                intent.putExtra("SearchQuery", searchQuery!!.text!!.toString())
                intent.putExtra("start_date", sDate)
                intent.putExtra("end_date", eDate)
                intent.putExtra("section", section)
                view.context.startActivity(intent)
            }
        }

    }

    private fun startActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}
