package com.example.megaport.mynews.Views

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.RequestManager
import com.example.megaport.mynews.Controllers.Utils.MyApplication
import com.example.megaport.mynews.Models.Article
import com.example.megaport.mynews.Models.Multimedium
import com.example.megaport.mynews.R
import java.lang.ref.WeakReference
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Date

import butterknife.BindView
import butterknife.ButterKnife

class FragmentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    // FOR DESIGN
    @BindView(R.id.fragment_main_item_section)
    var mSection: TextView? = null
    @BindView(R.id.fragment_main_item_title)
    var mTitle: TextView? = null
    @BindView(R.id.fragment_main_item_date)
    var mDate: TextView? = null
    @BindView(R.id.fragment_main_item_image)
    var mImage: ImageView? = null

    private val context = MyApplication.appContext
    private val nytimeslogo = context!!.getResources().getDrawable(R.drawable.ic_nytimes_logo)

    init {
        ButterKnife.bind(this, itemView)
    }

    // Update the UI with new results

    fun updateWithResult(article: Article, glide: RequestManager, callback: FragmentAdapter.Listener) {
        // Add an arrow head to the section of the article when it has a subsection
        var section = article.section
        if (article.subsection != null) {
            if (!article.subsection!!.isEmpty()) {
                section = section + " > " + article.subsection
            }
        }
        this.mSection!!.text = section

        // Parsing the updated date of the article to a new format and setting it the corresponding TextView
        var dtStart = article.publishedDate
        dtStart = dtStart!!.replace("T", " ")
        @SuppressLint("SimpleDateFormat") val format = SimpleDateFormat("yyyy-MM-dd")
        @SuppressLint("SimpleDateFormat") val formatR = SimpleDateFormat("dd/MM/yyyy")
        try {
            val date = format.parse(dtStart)
            dtStart = formatR.format(date)
            this.mDate!!.text = dtStart
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        val images: List<Multimedium>?
        if (article.media == null) {
            // Retrieving the thumbnail picture of the article
            images = article.multimedia
        } else {
            images = article.media!![0].multimedia
        }
        // If the article does not have any thumbnail : set a default thumbnail in the ImageView
        if (images!!.isEmpty()) {
            this.mImage!!.setImageDrawable(nytimeslogo)
        } else {
            for (i in images.indices) {
                glide.load(images[0].url).into(this.mImage!!)
            }
        }// Else set the corresponding thumbnail in the ImageView
        // Setting the title of the article
        this.mTitle!!.text = article.title
        val callbackWeakRef = WeakReference(callback)
    }

}
